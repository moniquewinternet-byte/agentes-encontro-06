---
name: crm
description: O painel do CRM. A pessoa VÊ seus contatos com status e histórico, e ATUALIZA conversando ("já avisei a fulana", "fulano virou cliente"). O agente grava no Supabase e gera um painel local e privado na identidade dela. Ela nunca mexe em tabela.
---

# O Painel do CRM

Aqui a lista de contatos vira um CRM de verdade: dá pra saber quem já foi contatado,
o que ficou combinado com cada um, e em que pé está. A pessoa NÃO edita tabela nem faz
login em tela nenhuma: ela CONVERSA e você registra.

## Duas coisas que você faz

### 1. Registrar (a pessoa fala, você grava)
A pessoa diz em linguagem normal e você traduz pra um UPDATE no Supabase:
- "já avisei a Juliana da turma" → status = `avisado`, nota = "avisei da turma", atualizado_em = agora
- "a Carla me respondeu, quer ver em dezembro" → status = `respondeu`, nota = "quer ver em dezembro"
- "a Déborah fechou!" → status = `cliente`, nota = o que ela contar
- "junta a Fernanda, entrou duas vezes" → apague a linha repetida (confirmando antes)

Status possíveis (simples): **novo · avisado · respondeu · cliente**. A pessoa pode
criar outro se quiser. Sempre grave `atualizado_em = now()`. Antes de apagar qualquer
coisa, confirme. Nunca invente nota: só escreve o que a pessoa disse.

### 2. Mostrar o painel (quando ela pede "me mostra meu CRM")
Leia todos os contatos do Supabase e gere um arquivo HTML LOCAL (ex.: `painel-crm.html`)
na pasta dela, e abra pra ela ver. O painel mostra cada pessoa com:
- nome e e-mail
- **status** (com uma cor), **nota** (o histórico em uma linha), quando entrou e a última atualização
Agrupe por status (cliente e respondeu primeiro, que pedem ação; novo por último).

## Cores do status (semânticas, não são a marca)
- novo = cinza · avisado = azul · respondeu = âmbar · cliente = verde
A identidade da pessoa (as cores e a fonte dela) fica no ENTORNO do painel; as cores de
status são sinal, iguais pra todo mundo, pra ela bater o olho e entender.

## Privacidade (importante)
O painel tem nome e e-mail de gente real, então ele é LOCAL e PRIVADO: fica na máquina
dela, NÃO publica no ar (diferente do link na bio, que é público). Nunca suba esse arquivo.
