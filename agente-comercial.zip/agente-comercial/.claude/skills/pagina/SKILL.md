---
name: pagina
description: Monta o link na bio da pessoa (uma página no ar com os links dela e um formulário que captura contato) a partir do perfil-do-negocio.md e da identidade visual dela. Use depois que o perfil já existe.
---

# O Designer

Seu trabalho é montar o LINK NA BIO da pessoa, com a cara dela, pronto pra publicar.
Você NÃO inventa: tudo vem do `perfil-do-negocio.md` (o que ela faz, a porta, o tom,
os links) e do `identidade.md` (as 3 cores e a fonte dela, que ela montou antes).

## Antes de montar
1. Leia `perfil-do-negocio.md`. Se não existir, peça pra rodar o `/entrevista` primeiro.
2. Leia `identidade.md` (3 cores + fonte). Se não existir, pergunte as 3 cores e a
   fonte, OU proponha uma paleta que combine com o tom dela e peça o ok. Nunca use a
   identidade de outra pessoa nem uma genérica sem confirmar.

## O que montar (uma página só, mobile primeiro)
- **Cabeçalho:** nome/marca, @ do Instagram, e uma tagline curta NO TOM dela.
- **Botões de link:** só os que estão no perfil (Instagram, material grátis, etc.).
  Nada de link que ela não deu.
- **A porta (o card principal):** é o que o perfil diz em "A porta". Se for lista de
  espera, um formulário com nome + e-mail. O título e o convite saem NO TOM dela,
  usando as regras e os trechos reais do perfil (frases curtas, as palavras dela, o
  emoji dela com moderação). A mensagem de sucesso também no tom dela.
- **Consentimento (LGPD):** um checkbox curto, desmarcado, "pode me avisar por e-mail".
- **Assinatura:** o @ dela no rodapé.

## Regras do tom (o que faz a página ter a cara dela)
- Reescreva os textos da porta aplicando as regras de "Tom de voz" do perfil. A mesma
  página pra outra pessoa teria outras palavras. Esse é o ponto.
- Respeite o limite de emoji dela. Não encha.
- Não prometa o que o perfil não diz (data de turma só se estiver lá).

## A parte técnica (já resolvida, não reinventar)
- As 3 cores e a fonte entram como tokens no `:root` do HTML (a pessoa troca num
  lugar só).
- O formulário grava no Supabase da pessoa por `fetch` POST, com a chave PÚBLICA
  (anon/publishable) e a tabela dela. Trava de segurança: RLS só-insert (a pessoa já
  criou a tabela assim). Não dependa do retorno do insert (use `Prefer: return-minimal`).
- Salve em `<pasta-da-pessoa>/index.html`.

## Publicar no Netlify (dois caminhos, a pessoa escolhe)
Depois de gerar a página, coloque no ar pelo Netlify:
- **Netlify Drop:** ela abre netlify.com/drop e arrasta a pasta da página. Sai com o link
  na hora, sem terminal nem login. É o mais simples.
- **Netlify CLI:** você publica pela pessoa com o `netlify-cli` (ela faz um login no Netlify
  uma vez, OAuth no navegador). Bom pra republicar depois sem arrastar de novo.
Mostre o link final. Essa página é PÚBLICA, pode compartilhar (diferente do painel do CRM,
que é privado). Dica pra turma: cada uma cola o link no grupo e as colegas preenchem, assim
os primeiros contatos já caem de verdade.
