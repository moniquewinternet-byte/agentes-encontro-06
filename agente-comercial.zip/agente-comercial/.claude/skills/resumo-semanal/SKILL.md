---
name: resumo-semanal
description: Roda sozinho uma vez por semana. Lê os contatos novos no Supabase, escreve um resumo curto pra pessoa, e de quebra mantém o banco ativo (o Supabase free pausa sem uso). É a parte automática que faz isso ser AGENTE, não só skill.
---

# A Automação (resumo semanal)

Você roda SOZINHO, por uma tarefa agendada, uma vez por semana. A pessoa não pede:
ela só encontra o resumo pronto quando abre.

## O que fazer
1. Leia a tabela de contatos no Supabase (conector autenticado).
2. Conte, POR CONSULTA (nunca de cabeça): quantos entraram nos últimos 7 dias, quem são,
   e o total da lista.
3. Escreva um resumo curto em `resumo-semana-<data>.md`:
   - "Essa semana entraram N pessoas na sua lista: [nomes]."
   - "Sua lista tem agora X pessoas no total."
   - O próximo passo lido do perfil (ex.: avisar quando abrir turma).
   - UMA linha de lembrete leve sobre o Supabase: "sua base está ativa (acabei de ler ela
     agora). Se você ficar uns dias sem ligar o computador, passa no Supabase pra ele não
     dormir, porque no plano grátis ele pausa quando fica sem uso." (reforço honesto; o
     keep-alive de verdade é esta rotina rodando, mas se o PC ficar dias desligado ela não roda.)
   - Se ninguém entrou, diga com honestidade e sugira divulgar o link.
4. Não mande mensagem pra ninguém (isso é o Redator). Você só avisa a DONA.

## O keep-alive (importante, explica na aula)
O Supabase grátis PAUSA o projeto depois de ~7 dias sem atividade, e aí o formulário
para de gravar. Como esta rotina LÊ a tabela toda semana, ela já toca o banco e o mantém
vivo. Um tiro, dois coelhos: resume E não deixa pausar.

## A verdade que a pessoa precisa saber
- A tarefa é LOCAL: só roda com o computador ligado e o app aberto. Não é um servidor 24h.
- Se a pessoa quiser 24h de verdade, o caminho é hospedar (nível seguinte), e aí vale o
  plano pago do Supabase pra nunca pausar.
