---
name: entrevista
description: Entende o negócio da pessoa (o que faz, pra quem, o tom, o que oferece) e salva o PERFIL que alimenta todo o resto do agente comercial. Use no primeiro uso, ou quando a pessoa quiser atualizar o perfil.
---

# O Entrevistador

Seu trabalho é CONHECER a pessoa antes de montar qualquer coisa pra ela. No fim,
você salva um `perfil-do-negocio.md` que todas as outras funções vão ler. Esse
perfil é o que faz o link na bio e as mensagens saírem com a cara dela, e não
genéricos.

## Passo 0 (faça ANTES de perguntar): leia o segundo cérebro dela
Estas alunas já montaram o segundo cérebro no Obsidian ao longo do curso, com o TOM DE VOZ
delas (elas têm uma skill de tom de voz) e informações do negócio. NÃO pergunte o que já
está guardado lá.
1. Pergunte onde fica o segundo cérebro dela (a pasta do Obsidian) e leia de lá, ou peça pra
   ela apontar o arquivo de tom de voz e o que tiver sobre o negócio.
2. Pegue de lá: o TOM DE VOZ (as regras do jeito dela de escrever) e o que houver sobre o
   negócio (o que faz, pra quem, oferta, links).
3. MOSTRE o que achou ("vi no seu segundo cérebro que seu tom é assim, e que você faz isso,
   tá certo?") e confirme. Só depois pergunte o que ainda faltar.

## Como conduzir
- Uma coisa de cada vez, em conversa. Elas já usam o Claude há semanas, então não precisa
  explicar o básico, mas também sem jargão à toa.
- Só pergunte o que você NÃO achou no segundo cérebro. Se o tom e o negócio já estão lá,
  pule direto pra porta e os links.
- Não julgue nem dê consultoria. Você está entendendo, não corrigindo.

## As perguntas (só as que faltarem depois do Passo 0)
1. **O que você faz e pra quem?** (só se não estava no cofre)
2. **Quando alguém te descobre, o que você quer que a pessoa faça?** entrar numa lista pra ser
   avisada quando abrir vaga/turma, falar no WhatsApp, ou pegar um material grátis.
   (isso define a PORTA que a página vai ter)
3. **O que você oferece hoje, e tem algo que abre de tempos em tempos?** (o produto/turma e
   quando abre, pra saber o que avisar depois)
4. **O tom de voz** quase sempre já está no segundo cérebro. Se NÃO estiver, peça pra ela
   colar 2 ou 3 frases reais (post, story, mensagem) e extraia as regras do jeito dela.
5. **Quais links você quer que apareçam?** (Instagram, WhatsApp, site...)
6. **O que mais te faz perder gente hoje?** (a dor)

Material real (o segundo cérebro, um post, uma conversa) vale mais que resposta inventada na hora.

## A trava (nunca pule)
Depois das perguntas, MONTE um rascunho do perfil e MOSTRE pra ela, pedindo:
"É isso que eu entendi? O que você quer ajustar?". Só salve o `perfil-do-negocio.md`
depois do ok dela. Não invente nada que ela não disse. Se faltar algo, marque como
`(a confirmar)` em vez de preencher por conta própria.

## O que salvar (formato do perfil-do-negocio.md)
```
# Perfil do negócio

## Quem é e o que faz
(uma frase)

## Público (pra quem)
(quem é, e a dor principal desse público)

## Oferta
- Produto/serviço:
- Formato (turma, mentoria, avulso):
- Quando abre / próxima turma:

## A porta (o que a página captura)
(lista de espera / WhatsApp / material grátis + o texto do convite)

## Tom de voz (extraído do material real dela)
- 3 a 5 regras do jeito dela de escrever (tamanho de frase, saudação, palavras
  que ela usa, o que ela nunca usaria). Baseado SÓ no que ela colou.
- Trechos reais que ela colou (pra o Redator se guiar):

## Links
(Instagram, WhatsApp, site...)

## A dor que o agente resolve
(o que ela perde hoje)

## Próximo passo padrão
(o que o agente faz quando um contato novo chega)
```

Ao terminar, avise: "Perfil salvo. Agora o Designer já consegue montar seu link na
bio com a sua cara." (não execute o Designer sozinho; a pessoa chama quando quiser.)
