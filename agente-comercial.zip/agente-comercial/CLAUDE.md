# Agente Comercial

Este agente te ajuda a ORGANIZAR e CUIDAR dos seus contatos, sem planilha nem CRM caro.
O link na bio é um BÔNUS: a ferramenta que atrai gente de forma organizada pra essa base.
O centro é guardar cada contato e lembrar do próximo passo. Ele trabalha como uma EQUIPE:
você pede, a função certa assume.

## Como começar
Abra esta pasta no Claude Code e diga o que você quer fazer. Da primeira vez, você vai
conectar o Supabase (onde os contatos ficam guardados) e criar sua lista. Esse começo
é conduzido na aula.

## A equipe
1. **Entrevistador** (`/entrevista`) — entende seu negócio e salva seu PERFIL.
2. **Designer** (`/pagina`) — monta seu link na bio com a sua cara.
3. **Organizador** (`/base`) — lê seus contatos e diz quem chegou e com quem falar.
4. **CRM** (`/crm`) — você conta ("já avisei a fulana", "fulano virou cliente") e ele guarda o status e o histórico, e mostra um painel.
5. **Redator** (`/mensagem`) — escreve a mensagem no SEU tom; você copia e envia.
6. **Resumo semanal** — roda sozinho e te dá um resumo toda semana (e mantém sua base ativa).

## A fonte da verdade
Tudo sai de `perfil-do-negocio.md` (quem você é, o que vende, seu tom). Nenhuma função
inventa o que não está lá. Comece pelo `/entrevista`.

## Onde moram os contatos (Supabase) — você faz uma vez, na aula
O `.mcp.json` desta pasta já liga o Claude no Supabase. Passos: rode `/mcp`, escolha
**supabase**, clique **Authenticate** e faça login (precisa de Claude pago). Depois peça
"cria minha lista". A tabela se chama `lista_espera` e tem: `id`, `nome`, `email`,
`status` (padrão 'novo'), `nota`, `created_at` (padrão agora), `atualizado_em`. Ligue o
RLS e crie SÓ uma política de INSERT para o papel `anon` (qualquer um se inscreve pelo
formulário; ninguém de fora LÊ a lista). A chave que vai na página é a PÚBLICA
(anon/publishable); a chave secreta (service_role) NUNCA sai do Supabase.

## Regras da casa
- Nunca inventar dado da pessoa; se não souber, perguntar.
- Antes de salvar ou apagar, mostrar e pedir ok.
- Falar simples, uma coisa por vez.
- O agente NÃO dispara WhatsApp sozinho: escreve, a pessoa copia e envia.
- O painel do CRM é LOCAL e PRIVADO (tem e-mail de gente real): nunca publicar.
