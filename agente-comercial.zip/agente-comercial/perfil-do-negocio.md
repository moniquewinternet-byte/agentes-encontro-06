# Perfil do negócio

> Este arquivo começa vazio. Rode `/entrevista` que o agente conversa com você e
> preenche tudo aqui. Depois é esta memória que faz sua página e suas mensagens
> saírem com a sua cara.

## Quem é e o que faz
(a confirmar)

## Público (pra quem)
(a confirmar)

## Oferta
- Produto/serviço:
- Formato (turma, mentoria, avulso):
- Quando abre / próxima turma:

## A porta (o que a página captura)
(lista de espera / WhatsApp / material grátis + o texto do convite)

## Tom de voz (extraído do material real dela)
- (regras do jeito dela de escrever)
- (trechos reais que ela colou)

## Links
(Instagram, WhatsApp, site...)

## A dor que o agente resolve
(a confirmar)

## Próximo passo padrão
(a confirmar)

## Supabase (preenchido no setup)
- URL do projeto:
- Chave pública (anon/publishable):
- Tabela: lista_espera
