# Minha identidade visual

> Coloque aqui as 3 cores e a fonte que você montou no Encontro 02 (a sua marca).
> O Designer usa isso pra sua página sair com a sua cara, não genérica.
> Troque os valores de exemplo abaixo pelos seus.

- Cor 1 (principal): #0057B8
- Cor 2 (apoio): #FF6B2B
- Cor 3 (acento): #FF3E8A
- Fundo: #F4F6F9
- Fonte de título: Poppins
- Fonte de corpo: Inter
